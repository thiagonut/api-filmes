//importando dos modulos necessarios
const express = require('express');
const cors = require('cors');//pacote cors para lidar com solicitações de diferentes origins
const filmes = require('./filmes.json');
const path = require('path');
const exp = require('constants');

const app = express();

const PORT = 8080;

app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

//definição da rota para os filmes
app.get('/filmes', (req, res)=>{
    res.json(filmes);//retorna os dados dos filmes como uma reposta json
})

app.listen(PORT,() => {
    console.log('Servidor em execução em http://localhost:${PORT}')
})